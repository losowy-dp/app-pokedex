package com.example.apppokedex.data.remote.responses

data class AbilityX(
    val name: String,
    val url: String
)