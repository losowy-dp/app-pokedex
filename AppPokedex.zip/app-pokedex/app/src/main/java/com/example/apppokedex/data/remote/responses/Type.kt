package com.example.apppokedex.data.remote.responses

data class Type(
    val slot: Int,
    val type: TypeX
)