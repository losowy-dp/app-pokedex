package com.example.apppokedex.data.remote.responses

data class MoveLearnMethod(
    val name: String,
    val url: String
)