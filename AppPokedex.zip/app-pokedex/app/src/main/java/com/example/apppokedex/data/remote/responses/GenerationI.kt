package com.example.apppokedex.data.remote.responses

data class GenerationI(
    val red_blue: RedBlue,
    val yellow: Yellow
)