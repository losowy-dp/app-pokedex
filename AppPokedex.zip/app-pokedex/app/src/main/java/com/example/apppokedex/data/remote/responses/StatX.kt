package com.example.apppokedex.data.remote.responses

data class StatX(
    val name: String,
    val url: String
)