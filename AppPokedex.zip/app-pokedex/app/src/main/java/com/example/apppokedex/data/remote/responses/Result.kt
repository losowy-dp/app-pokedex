package com.example.apppokedex.data.remote.responses

data class Result(
    val name: String,
    val url: String
)