package com.example.apppokedex.data.remote.responses

data class OfficialArtwork(
    val front_default: String
)