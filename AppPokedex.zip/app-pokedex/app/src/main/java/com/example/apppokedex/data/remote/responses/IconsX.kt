package com.example.apppokedex.data.remote.responses

data class IconsX(
    val front_default: String,
    val front_female: Any
)