package com.example.apppokedex.data.remote.responses

data class GenerationVii(
    val icons: Icons,
    val ultra_sun_ultra_moon: UltraSunUltraMoon
)