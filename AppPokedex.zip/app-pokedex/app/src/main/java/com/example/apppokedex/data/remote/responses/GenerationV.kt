package com.example.apppokedex.data.remote.responses

data class GenerationV(
    val black_white: BlackWhite
)