package com.example.apppokedex.data.remote.responses

data class TypeX(
    val name: String,
    val url: String
)