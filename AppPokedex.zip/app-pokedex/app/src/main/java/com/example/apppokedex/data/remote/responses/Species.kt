package com.example.apppokedex.data.remote.responses

data class Species(
    val name: String,
    val url: String
)