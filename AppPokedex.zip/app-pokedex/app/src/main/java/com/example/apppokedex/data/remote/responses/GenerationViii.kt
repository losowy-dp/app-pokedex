package com.example.apppokedex.data.remote.responses

data class GenerationViii(
    val icons: IconsX
)