package com.example.apppokedex.data.remote.responses

data class GenerationIi(
    val crystal: Crystal,
    val gold: Gold,
    val silver: Silver
)